/*
 * Senser_data.c
 *
 *  Created on: Jan 24, 2024
 *      Author: LIUBIN
 */
#include "Senser_data.h"
#include "emu_uart.h"
Senser_data Imu;

void FrameData_Init(Senser_data *frame,uint8_t header ,uint8_t end)
{
	frame->FrameHeader=header;
	frame->FrameEnd=end;
	frame->FrameLength=MaxLength;
}

void SetFrameData(Senser_data *frame,uint8_t *data,uint8_t len)
{
	frame->FrameData[0]=frame->FrameHeader;

	for(uint8_t i=0;i<len;i++)
	{
		frame->FrameData[1+i]=*(data++);
	}

	frame->FrameData[MaxLength-1]=frame->FrameEnd;
}

uint8_t BCC_CheckSum( Senser_data* frame)//异或校验
{
    uint8_t bcc = 0;
    uint8_t *data=frame->FrameData;
	int len=frame->FrameLength-2;//将校验位前的数据进行异或
    for(int i=0;i<len;i++)
    {
    	bcc^=data[i];
    }
    frame->Check=bcc;
    frame->FrameData[MaxLength-2]=bcc;
    return bcc;
}
void SendFrame(Senser_data *frame)
{
	Uart_tx_bytes(frame->FrameData,MaxLength);
}
