#include "emu_uart.h"


#define DATE1 104 		// ������ 9600
#define DATE2 50			// ������ 19200
//#define DATE3 26		  // ������ 38400

#define DATEX DATE2

#define TX_H HAL_GPIO_WritePin(EMU_TX_GPIO_Port,GPIO_PIN_10,GPIO_PIN_SET)
#define TX_L HAL_GPIO_WritePin(EMU_TX_GPIO_Port,GPIO_PIN_10,GPIO_PIN_RESET)




void Uart_tx_one_byte (uint8_t date)
{
	int i;
	
	TX_L;
	Delay_uS(DATEX);
	
	for(i=0;i<8;i++)
	{
		if(date&(0x01<<i))
		{
			TX_H;
		}
		else
		{
			TX_L;
		}
		Delay_uS(DATEX);
	}
	
	TX_H;
	Delay_uS(DATEX);
}	
//���Ͷ���ֽ�//
void Uart_tx_bytes(uint8_t *pdata ,uint8_t len)
{
	uint8_t i;
	for(i=0;i<len;i++)
	{
		Uart_tx_one_byte(*(pdata+i));
	}
}
