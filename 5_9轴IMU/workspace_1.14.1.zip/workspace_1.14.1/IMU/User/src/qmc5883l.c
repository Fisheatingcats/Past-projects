/*
 * qmc5883l.c
 *
 *  Created on: Jan 25, 2024
 *      Author: LIUBIN
 */
#include "qmc5883l.h"
#include "stdio.h"

uint8_t qmc5883l_buf[6];

void QMC5883L_WriteReg(uint8_t addr,uint8_t reg_data)
{
	EMU_I2C_Start();
	EMU_I2C_SendByte(QMC5883L_ADDR_WRITE);
	EMU_I2C_ReceiveAck();
	EMU_I2C_SendByte(addr);
	EMU_I2C_ReceiveAck();
	EMU_I2C_SendByte(reg_data);
	EMU_I2C_ReceiveAck();
	EMU_I2C_Stop();
}

uint8_t QMC5883L_ReadReg(uint8_t addr)
{
	uint8_t reg_data;
	EMU_I2C_Start();
	EMU_I2C_SendByte(QMC5883L_ADDR_WRITE);
	EMU_I2C_ReceiveAck();
	EMU_I2C_SendByte(addr);
	EMU_I2C_ReceiveAck();
	EMU_I2C_Start();
	EMU_I2C_SendByte(QMC5883L_ADDR_READ);
	EMU_I2C_ReceiveAck();
	reg_data=EMU_I2C_ReceiveByte();
	EMU_I2C_SendAck(1);
	EMU_I2C_Stop();
	return reg_data;
}

void QMC5883L_Multiple_Read(void)
{
	EMU_I2C_Start();
	EMU_I2C_SendByte(QMC5883L_ADDR_WRITE);
	EMU_I2C_ReceiveAck();
	EMU_I2C_SendByte(QMC5883L_ADDR_XOUTL);
	EMU_I2C_ReceiveAck();
	EMU_I2C_Start();
	EMU_I2C_SendByte(QMC5883L_ADDR_READ);
	EMU_I2C_ReceiveAck();
	for(int i=0;i<6;i++)
	{
		qmc5883l_buf[i]=EMU_I2C_ReceiveByte();
		if(i==5){EMU_I2C_SendAck(1);}
		else{EMU_I2C_SendAck(0);}

	}
	EMU_I2C_Stop();
	HAL_Delay(5);
}

uint8_t QMC5883L_ReadID()
{
	return QMC5883L_ReadReg(QMC5883L_ADDR_CHIPID);
}

uint8_t QMC5883L_Init(void)
{

	uint8_t outtime;
	while(QMC5883L_ReadID()!=QMC5883L_CHIPID_VALUE)
	{
		outtime++;
		if(outtime>=250)
		{
			return 0;
		}
	}

	HAL_Delay(50);

	QMC5883L_WriteReg(0x0b,0x01);
	QMC5883L_WriteReg(0x20,0x40);
	QMC5883L_WriteReg(0x21,0x01);
	QMC5883L_WriteReg(QMC5883L_ADDR_CFGA ,QMC5883L_CFGA_VALUE_CONTINUE);

	if(QMC5883L_ReadReg(QMC5883L_ADDR_CFGA) !=QMC5883L_CFGA_VALUE_CONTINUE)
		    {
				printf("reg=0x%d",QMC5883L_ReadReg(QMC5883L_ADDR_CFGA));
		        return 0;
		    }
	return 1;
}

//磁力计软复位
void QMC5883L_Soft_Reset(void)
{
	QMC5883L_WriteReg(QMC5883L_ADDR_CFGB ,QMC5883L_CFGB_VALUE_REBOOT);
    HAL_Delay(50);
}


