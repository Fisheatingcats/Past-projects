/*
 * scheduler_task.c
 *
 *  Created on: Jan 24, 2024
 *      Author: LIUBIN
 */


#include "scheduler_task.h"

#include "led.h"
#include "emu_uart.h"
#include "Senser_data.h"
#include "mpu6050.h"
#include "stdio.h"
#include "qmc5883l.h"
#include "math.h"

void FrameSend();

extern uint8_t ReadState;

uint8_t task_num;

scheduler_task_type Scheduler_Task[]={

		{FrameSend,20,0}
};//任务数组

void Scheduler_Init(void)
{
	task_num =sizeof(Scheduler_Task)/sizeof(scheduler_task_type);
}


void Scheduler_Run(void)
{
	for(int i=0;i<task_num;i++)
	{
		uint32_t now_time= HAL_GetTick();//获取系统当前运行时间
		if(now_time-Scheduler_Task[i].last_run>=Scheduler_Task[i].rate_ms)
		{
			Scheduler_Task[i].last_run=now_time;
			Scheduler_Task[i].task_fun();
		}
	}
}


void FrameSend()
{
	if(Deviation_Count>=MAX_COUNT )
	{
	 //初始化数组
		uint8_t buf[DataLength]={0x00,0x00,
			 0x00, 0x00,0x00,0x00,0x00,0x00,
			 0x00,0x00,0x00,0x00,0x00,0x00,
			 0x00,0x00,0x00,0x00,0x00};
		GetMPU6050Data();
	 	 buf[0]=gyro[0]>>8;
	 	 buf[1]=gyro[0];
	 	 buf[2]=gyro[1]>>8;
	 	 buf[3]=gyro[1];
	 	 buf[4]=gyro[2]>>8;
	 	 buf[5]=gyro[2];



	 	 buf[6]=accel[0]>>8;
	 	 buf[7]=accel[0];
		 buf[8]=accel[1]>>8;
		 buf[9]=accel[1];
		 buf[10]=accel[2]>>8;
		 buf[11]=accel[2];
		 QMC5883L_Multiple_Read();
		 for(int i=0;i<6;i++)
	 	 {
	 		 buf[i+12]=qmc5883l_buf[i];
	 	 }
		 uint8_t tempbuf[2];
		 MPU6050_ReadData(MPU6050_RA_TEMP_OUT_H,tempbuf,2);//读取mpu6050 温度计
		 buf[18]=tempbuf[0];
		 buf[19]=tempbuf[1];

		 SetFrameData(&Imu,buf,DataLength);//将缓冲区数组送入数据帧
		 BCC_CheckSum(&Imu);//XOR校验
		 SendFrame(&Imu);//发送一帧数据

	}
}
/*
void Fun2()
{
//	int x,y,z;
//	int dataX,dataY,dataZ;
	printf("qmc5883l:ID=0x%x\n",QMC5883L_ReadID());
	//QMC5883L_Multiple_Read();


	qmc5883l_buf[0]=QMC5883L_ReadReg(QMC5883L_ADDR_XOUTL);
	qmc5883l_buf[1]=QMC5883L_ReadReg(QMC5883L_ADDR_XOUTH);
	qmc5883l_buf[2]=QMC5883L_ReadReg(QMC5883L_ADDR_YOUTL);
	qmc5883l_buf[3]=QMC5883L_ReadReg(QMC5883L_ADDR_YOUTH);
	qmc5883l_buf[4]=QMC5883L_ReadReg(QMC5883L_ADDR_ZOUTL);
	qmc5883l_buf[5]=QMC5883L_ReadReg(QMC5883L_ADDR_ZOUTH);


//	dataX=(int)(qmc5883l_buf[1]<<8)+qmc5883l_buf[0];
//	dataY=(int)(qmc5883l_buf[3]<<8)+qmc5883l_buf[2];
//	dataZ=(int)(qmc5883l_buf[5]<<8)+qmc5883l_buf[4];


	printf("0X%x%x\n",qmc5883l_buf[0],qmc5883l_buf[1]);
	printf("0X%x%x\n",qmc5883l_buf[2],qmc5883l_buf[3]);
	printf("0X%x%x\n",qmc5883l_buf[4],qmc5883l_buf[5]);


}
*/
