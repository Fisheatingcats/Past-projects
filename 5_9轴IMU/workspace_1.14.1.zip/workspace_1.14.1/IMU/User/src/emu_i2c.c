/*
 * emu_i2c.c
 *
 *  Created on: Jan 25, 2024
 *      Author: LIUBIN
 */


#include "emu_i2c.h"

#define EMU_I2C_SDA_L 	HAL_GPIO_WritePin(I2C_SDA_GPIO_Port,I2C_SDA_Pin,GPIO_PIN_RESET);
#define EMU_I2C_SDA_H 	HAL_GPIO_WritePin(I2C_SDA_GPIO_Port,I2C_SDA_Pin,GPIO_PIN_SET);
#define EMU_I2C_SCL_L	 	HAL_GPIO_WritePin(I2C_SCL_GPIO_Port,I2C_SCL_Pin,GPIO_PIN_RESET);
#define EMU_I2C_SCL_H 	HAL_GPIO_WritePin(I2C_SCL_GPIO_Port,I2C_SCL_Pin,GPIO_PIN_SET);


void EMU_I2C_SDA(uint8_t state)
{
	HAL_GPIO_WritePin(I2C_SDA_GPIO_Port,I2C_SDA_Pin,(GPIO_PinState)state);
	Delay_uS(10);
}

void EMU_I2C_SCL(uint8_t state)
{
	HAL_GPIO_WritePin(I2C_SCL_GPIO_Port,I2C_SCL_Pin,(GPIO_PinState)state);
	Delay_uS(10);
}

uint8_t EMU_I2C_R_SDA(void)
{
	uint8_t value;
	value=HAL_GPIO_ReadPin(I2C_SDA_GPIO_Port, I2C_SDA_Pin);
	Delay_uS(10);
	return value;
}

void EMU_I2C_Start()
{
	EMU_I2C_SDA(1);
	EMU_I2C_SCL(1);
	EMU_I2C_SDA(0);
	EMU_I2C_SCL(0);
}

void EMU_I2C_Stop()
{
	EMU_I2C_SDA(0);
	EMU_I2C_SCL(1);
	EMU_I2C_SDA(1);
}

void EMU_I2C_SendAck(uint8_t ack)
{
	EMU_I2C_SDA(ack);
	EMU_I2C_SCL(1);
	EMU_I2C_SCL(0);
}

uint8_t EMU_I2C_ReceiveAck()
{
	uint8_t ans;
	EMU_I2C_SDA(1);
	EMU_I2C_SCL(1);
	ans=HAL_GPIO_ReadPin(I2C_SDA_GPIO_Port, I2C_SDA_Pin);
	EMU_I2C_SCL(0);

	return ans;
}

void EMU_I2C_SendByte(uint8_t byte)
{
	for(uint8_t i=0;i<8;i++)
	{
		EMU_I2C_SDA(byte&(0x80>>i));
		EMU_I2C_SCL(1);
		EMU_I2C_SCL(0);
	}
}

uint8_t EMU_I2C_ReceiveByte(void)
{
	uint8_t Byte = 0x00;
	EMU_I2C_SDA(1);
	for (uint8_t i = 0; i < 8; i ++)
	{
		EMU_I2C_SCL(1);
		if (EMU_I2C_R_SDA()) {Byte |= (0x80 >> i);}
		EMU_I2C_SCL(0);
	}
	return Byte;
}
