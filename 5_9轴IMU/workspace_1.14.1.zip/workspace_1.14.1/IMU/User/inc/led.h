/*
 * led.h
 *
 *  Created on: Jan 24, 2024
 *      Author: LIUBIN
 */

#ifndef INC_LED_H_
#define INC_LED_H_

#include "main.h"

//#define LED_Toggle 	HAL_GPIO_TogglePin(LED_GPIO_Port,LED_Pin);
#define LED_ON 		HAL_GPIO_WritePin(LED_GPIO_Port,LED_Pin,GPIO_PIN_RESET);
#define LED_OFF 	HAL_GPIO_WritePin(LED_GPIO_Port,LED_Pin,GPIO_PIN_SET);

void LED_Toggle(void);

#endif /* INC_LED_H_ */
