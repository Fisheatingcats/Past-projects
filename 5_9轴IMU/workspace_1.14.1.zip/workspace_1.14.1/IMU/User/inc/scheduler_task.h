/*
 * scheduler_task.h
 *
 *  Created on: Jan 24, 2024
 *      Author: LIUBIN
 */

#ifndef INC_SCHEDULER_TASK_H_
#define INC_SCHEDULER_TASK_H_

#include "main.h"

typedef struct scheduler_task_type
{
	void (*task_fun)(void);
	uint16_t rate_ms;
	uint32_t last_run;

}scheduler_task_type;



void Scheduler_Init(void);
void Scheduler_Run(void);

#endif /* INC_SCHEDULER_TASK_H_ */
