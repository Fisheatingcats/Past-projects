/*
 * Senser_data.h
 *
 *  Created on: Jan 24, 2024
 *      Author: LIUBIN
 */

#ifndef SRC_SENSER_DATA_H_
#define SRC_SENSER_DATA_H_

#include "stm32f1xx_hal.h"

#define StartingLength 3   	//数据帧的帧头、帧尾、校验位需要占用的字节数
#define MaxLength      22	//一帧数据的总长度
#define DataLength     MaxLength-StartingLength	//存放数据所占字节长度

typedef struct Senser_data
{
	uint8_t FrameLength;
	uint8_t FrameHeader;
	uint8_t Check;
	uint8_t FrameEnd;
	uint8_t FrameData[MaxLength];

}Senser_data;

extern Senser_data Imu;

void FrameData_Init(Senser_data *frame,uint8_t header ,uint8_t end);
void SetFrameData(Senser_data *frame,uint8_t *data,uint8_t len);
void SendFrame(Senser_data *frame);
uint8_t BCC_CheckSum( Senser_data* senser_data);

#endif /* SRC_SENSER_DATA_H_ */
