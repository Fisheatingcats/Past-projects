/*
 * emu_i2c.h
 *
 *  Created on: Jan 25, 2024
 *      Author: LIUBIN
 */

#ifndef INC_EMU_I2C_H_
#define INC_EMU_I2C_H_

#include "main.h"
#include "tim.h"

void EMU_I2C_SDA(uint8_t state);
void EMU_I2C_SCL(uint8_t state);
uint8_t EMU_I2C_R_SDA(void);
void EMU_I2C_Start();
void EMU_I2C_Stop();
void EMU_I2C_SendAck(uint8_t ack);
uint8_t EMU_I2C_ReceiveAck();
void EMU_I2C_SendByte(uint8_t byte);
uint8_t EMU_I2C_ReceiveByte(void);



#endif /* INC_EMU_I2C_H_ */
