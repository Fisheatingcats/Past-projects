/*
 * qmc5883l.h
 *
 *  Created on: Jan 25, 2024
 *      Author: LIUBIN
 */

#ifndef INC_QMC5883L_H_
#define INC_QMC5883L_H_

#include "main.h"
#include "emu_i2c.h"

/*
***********************************************************************************************
*                                         INCLUDE FILES
***********************************************************************************************
*/
//......
/*
***********************************************************************************************
*                                            DEFINES
***********************************************************************************************
*/
/* 器件地址：设备从地址+读写选择 */
#define	QMC5883L_ADDR_WRITE                     0x1A
#define	QMC5883L_ADDR_READ	                	0x1B

/* 设备寄存器地址 */
#define	QMC5883L_ADDR_XOUTL                     0x00
#define	QMC5883L_ADDR_XOUTH                     0x01
#define	QMC5883L_ADDR_YOUTL                    0x02
#define	QMC5883L_ADDR_YOUTH                     0x03
#define	QMC5883L_ADDR_ZOUTL                     0x04
#define 	QMC5883L_ADDR_ZOUTH                     0x05

#define	QMC5883L_ADDR_STATUS                    0x06
#define	QMC5883L_ADDR_TEMPL                     0x07
#define	QMC5883L_ADDR_TEMPH                     0x08
#define	QMC5883L_ADDR_CFGA                      0x09
#define	QMC5883L_ADDR_CFGB                      0x0A
#define QMC5883L_ADDR_PERIORC                   0x0B
#define QMC5883L_ADDR_CHIPID                    0x0D

#define	QMC5883L_ADDR_CFGC                      0x20
#define	QMC5883L_ADDR_CFGD                      0x21

/* 设备寄存器参数值 */
#define QMC5883L_CFGA_OSR_512                   (0 << 7) | (0 << 6)
#define QMC5883L_CFGA_OSR_256                   (0 << 7) | (1 << 6)
#define QMC5883L_CFGA_OSR_128                   (1 << 7) | (0 << 6)
#define QMC5883L_CFGA_OSR_64                    (1 << 7) | (1 << 6)
#define QMC5883L_CFGA_RNG_2G                    (0 << 5) | (0 << 4)
#define QMC5883L_CFGA_RNG_8G                    (0 << 5) | (1 << 4)
#define QMC5883L_CFGA_ODR_10HZ                  (0 << 3) | (0 << 2)
#define QMC5883L_CFGA_ODR_50HZ                  (0 << 3) | (1 << 2)
#define QMC5883L_CFGA_ODR_100HZ                 (1 << 3) | (0 << 2)
#define QMC5883L_CFGA_ODR_200HZ                 (1 << 3) | (1 << 2)
#define QMC5883L_CFGA_MODE_STANDBY              (0 << 1) | (0 << 0)
#define QMC5883L_CFGA_MODE_CONTINUE             (0 << 1) | (1 << 0)

#define QMC5883L_CFGB_SOFT_RST                  (1 << 7)
#define QMC5883L_CFGB_ROL_PNT                   (1 << 6)
#define QMC5883L_CFGB_INT_ENB                   (1 << 0)

#define QMC5883L_CHIPID_VALUE                   0xFF                            /* 器件标识,0XFF */

#define QMC5883L_CFGA_VALUE_STANDBY             ( QMC5883L_CFGA_OSR_512        \
                                                | QMC5883L_CFGA_RNG_8G         \
                                                | QMC5883L_CFGA_ODR_200HZ      \
                                                | QMC5883L_CFGA_MODE_STANDBY )  /* OSR = 512;RNG = 8G;ODR=200Hz;MODE:待机模式 */

#define QMC5883L_CFGA_VALUE_CONTINUE            ( QMC5883L_CFGA_OSR_512        \
                                                | QMC5883L_CFGA_RNG_8G         \
                                                | QMC5883L_CFGA_ODR_200HZ      \
                                                | QMC5883L_CFGA_MODE_CONTINUE ) /* OSR = 512;RNG = 8G;ODR=200Hz;MODE:连续模式 */

#define QMC5883L_CFGB_VALUE_REBOOT              ( QMC5883L_CFGB_SOFT_RST )      /* QMC5883L软件重启 */

#define QMC5883L_CFGC_VALUE                     0x40
#define QMC5883L_CFGD_VALUE                     0x01
#define QMC5883L_PERIORC_VALUE                  0x01

#define QMC5883L_XYZBUF_LEN                     0x06
#define QMC5883L_TEMBUF_LEN                     0x02

#define QMC5883L_SENSITIVITY_2G                 ( 12 )
#define QMC5883L_SENSITIVITY_8G                 ( 3 )

#define QMC5883L_CUM_REBOOT_MAXCNT              ( 100 )                         /* 磁力计累计重启最大次数 */
#define QMC5883L_CON_REBOOT_MAXCNT              QMC5883L_CUM_REBOOT_MAXCNT      /* 磁力计连续重启最大次数 */



#define QMC5883L_READ_TEMP                                                      /* 使用QMC58883L内部温度 */


 extern uint8_t qmc5883l_buf[6];

 void QMC5883L_WriteReg(uint8_t addr,uint8_t reg_data);
 uint8_t QMC5883L_ReadReg(uint8_t addr);
 void QMC5883L_Multiple_Read(void);
 uint8_t QMC5883L_ReadID();
 uint8_t QMC5883L_Init(void);
 void QMC5883L_Soft_Reset(void);

#endif /* INC_QMC5883L_H_ */
