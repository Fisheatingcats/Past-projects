#ifndef __EMU_UART_H__
#define __EMU_UART_H__

#include "main.h"
#include "tim.h"
#define TX_DATA_MAX 21 



void Uart_tx_one_byte (uint8_t date);
void Uart_tx_bytes(uint8_t *pdata ,uint8_t len);
#endif
